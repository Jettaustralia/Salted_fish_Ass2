function submit_message(username, password) {
        $.post( "/login", {username: username, password:password}, handle_response);

        function handle_response(data) {
          // request.setRequestHeader("AUTH_TOKEN", data.token);
          // window.alert(data)
          $.ajax({
            type: "GET",
            url: "/log_in",
            beforeSend: function(request) {
                request.setRequestHeader("AUTH_TOKEN", data.token);
            },
            success:function (res) {
              location.href="chat";        
            },
          });
        }
	}
	
$('#submit').click(function(e){
    e.preventDefault();
		const username = $('#username').val()
		const password = $('#password').val()
		submit_message(username, password)
});