# /index.py
from flask import Flask, request, jsonify, render_template
import os
import dialogflow
import requests
import json
import pusher
from flask import request,jsonify
from flask import Flask
from api_test import detect_intent_texts
from flask_restful import Resource, Api,fields
import pymysql


# initialize Pusher
pusher_client = pusher.Pusher(
    app_id="901419",
    key='725a548612bda40b3e75',
    secret='f086129b76c9c4689413',
    cluster='ap1',
    ssl=True)

def after_request(response):
	response.headers['Access-Control-Allow-Origin'] = '*'
	response.headers['Access-Control-Allow-Methods'] = 'PUT,GET,POST,DELETE'
	response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
	return response
	
app = Flask(__name__)
app.after_request(after_request)
api = Api(app)



@app.route('/')
def index():
    return render_template('index.html')


@app.route('/get_movie_detail', methods=['POST'])
def get_movie_detail():
    data = request.get_json(silent=True)
    movie = data['queryResult']['parameters']['movie']
    api_key = '2d790008'

    movie_detail = requests.get('http://www.omdbapi.com/?t={0}&apikey={1}'.format(movie, api_key)).content
    movie_detail = json.loads(movie_detail)
    response =  """
        Title : {0}
        Released: {1}
        Actors: {2}
        Plot: {3}
    """.format(movie_detail['Title'], movie_detail['Released'], movie_detail['Actors'], movie_detail['Plot'])

    reply = {
        "fulfillmentText": response,
    }

    return jsonify(reply)


def detect_intent_texts(project_id, session_id, text, language_code):
    session_client = dialogflow.SessionsClient()
    session = session_client.session_path(project_id, session_id)

    if text:
        text_input = dialogflow.types.TextInput(
            text=text, language_code=language_code)
        query_input = dialogflow.types.QueryInput(text=text_input)        
        response = session_client.detect_intent(
            session=session, query_input=query_input)
        # print(response.query_result.parameters.fields["Movie"].string_value)
        # return response.query_result.fulfillment_text
        return response.query_result.parameters.fields["Movie"].string_value
    
def get_movie_info(movie_name):
	db = pymysql.connect(host='database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com', user='admin', password='19950423',port=3306, db='Movie')
	cursor = db.cursor()
	response = ''
	sql_query = "SELECT Description FROM movie where Title = %s"
	cursor.execute(sql_query, movie_name)
	result = cursor.fetchall()
	db.commit()
	if not result:
		response += f"Sorry,there is no movie called {movie_name},please check it"
	else:
		result = result[0][0]
		response += str(result)
    print(response)
	return response


@app.route('/send_message', methods=['POST'])
def send_message():
    
    try:
        socketId = request.form['socketId']
    except KeyError:
        socketId = ''
        
    message = request.form['message']
    project_id = 'movie-bot-ciwfrn'
    # fulfillment_text = detect_intent_texts(project_id, "unique", message, 'en')
    movie_name = detect_intent_texts(project_id, "unique", message, 'en')
    fulfillment_text = get_movie_info(movie_name)
    response_text = { "message":  fulfillment_text }

    print(socketId)
    # socketId = request.form['socketId']
    # pusher_client.trigger('movie_bot', 'new_message', 
    #                      {'human_message': message, 'bot_message': fulfillment_text},
    #                      socketId)

    
    return jsonify(response_text)


# run Flask app
if __name__ == "__main__":
    app.run()
   
"""
class moive_bot(Resource):
	def post(self,session_id,user_input):
		response = detect_intent_texts(2, user_input)
		if response.query_result.intent.display_name == 'Default Fallback Intent' :
			return "I am quite confused"
		if "Movie_name" in response.query_result.parameters :
			print(1)
			movie_name = response.query_result.parameters.fields["Movie_name"].string_value.replace("<","").replace(">","")
			response = get_movie_info(movie_name)
			return response,200
		return response.query_result.fulfillment_text,200
		
api.add_resource(moive_bot,'/<string:session_id>/<string:user_input>')
"""

database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com