import os
from flask import Flask, request, jsonify, render_template
import dialogflow
import requests
import json
import pusher
from flask import request,jsonify
from flask import Flask
from flask_restful import Resource, Api,fields
import pymysql

db = pymysql.connect(host='database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com', user='admin', password='19950423',port=3306, db='Movie')
cursor = db.cursor()

def after_request(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'PUT,GET,POST,DELETE'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
    return response
#def connect_to_db():
    
app = Flask(__name__)
app.after_request(after_request)
api = Api(app)


def detect_intent_texts(session_id, texts, language_code='en-US',project_id='movie-qijbmr'):
    path = os.path.join((os.path.dirname(os.path.abspath('api_test.py'))),
                        'Movie-a8de2ddc64b9.json')
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = path
    session_client = dialogflow.SessionsClient()

    session = session_client.session_path(project_id, session_id)
    text_input = dialogflow.types.TextInput(
        text=texts, language_code=language_code)
    query_input = dialogflow.types.QueryInput(text=text_input)
    response = session_client.detect_intent(
        session=session, query_input=query_input)       
    return response
    
def get_movie_info(movie_name):    
    response = ''
    sql_query = "SELECT Description FROM movie where Title = %s"
    cursor.execute(sql_query, movie_name)
    result = cursor.fetchall()
    db.commit()
    # print('result', result)
    if not result:
        response += f"Sorry,there is no movie called {movie_name},please check it"
    else:
        result = result[0][0]
        response += str(result)
    return response

def movie_recommed(movie_type):
    response = ''
    print(movie_type)
    movie_type_1 = "%" + movie_type + "%"
    response = ''
    sql_query = "SELECT Title FROM movie where Genre like %s order by Rating DESC "
    cursor.execute(sql_query, movie_type_1)
    result = cursor.fetchall()
    response += f"Here are top rating {movie_type} movie for you:\n"
    if len(result) > 5:
        for i in range(5):
            response += (result[i][0])
            response += "\n"
    else:
        for i in range(len(result)):
            response += (result[i][0])
            response += "\n"
    print(response)
    return response

def recommend_top_movie():
    response = ''
    response = 'Here are top10 rating movies for you:\n'
    sql_query = "SELECT Title FROM movie order by Metascore DESC "
    cursor.execute(sql_query)
    result = cursor.fetchall()
    for i in range(10):
        response += (result[i][0])
        response += "\n"
    print(response)
    return response


@app.route('/')
def chat():
    return render_template('chat.html')

@app.route('/movie_bot', methods=['POST'])
def movie_bot():           
    message = request.form['message']
    response = detect_intent_texts(2, message)
    if response.query_result.intent.display_name == 'Default Fallback Intent' :
        fulfillment_text = "I am quite confused"
        response_text = { "message":  fulfillment_text }
        return jsonify(response_text)
    if "Movie_name" in response.query_result.parameters :
        print(1)
        movie_name = response.query_result.parameters.fields["Movie_name"].string_value.replace("<","").replace(">","")
        print(movie_name)
        response = get_movie_info(movie_name)
        # print(response)
        fulfillment_text = response
        response_text = { "message":  fulfillment_text }
        return jsonify(response_text)
    if "movie_type" in response.query_result.parameters :
        # print(response.query_result.parameters)
        movie_type = response.query_result.parameters.fields["movie_type"].string_value
        response = movie_recommed(movie_type)
        fulfillment_text = response
        response_text = { "message":  fulfillment_text }
        return jsonify(response_text)
    if "recommend_part" in response.query_result.parameters:
        response = recommend_top_movie()
        fulfillment_text = response
        response_text = { "message":  fulfillment_text }
        return jsonify(response_text)
    
    fulfillment_text = response.query_result.fulfillment_text
    response_text = { "message":  fulfillment_text }
    return jsonify(response_text)



if __name__ == "__main__":
    app.run(debug=True)
