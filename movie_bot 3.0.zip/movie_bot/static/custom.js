
    function submit_message(message) {
        $.post( "/movie_bot/"+message, {message: message}, handle_response);

        function handle_response(data) {
          // append the bot repsonse to the div
          $('.chat-container').append(`
                <div class="chat-message bottalk"><span>
                    ${data.message}</span>
                </div>
          `)
          // remove the loading indicator
          $( "#loading" ).remove();
          document.getElementById("words").scrollTop=document.getElementById("words").scrollHeight
        }
    }

    document.onkeydown=function(e){	
      var keyNum=window.event ? e.keyCode :e.which;	
      
      if(keyNum==13){
      //  alert('huiche');
      const input_message = $('#input_message').val()
        // return if the user does not enter any text
        if (!input_message) {
          return
        }

        $('.chat-container').append(`
            <div class="chat-message humantalk" ><span>
                ${input_message.replace("<","&lt;").replace(">","&gt;")}
                </span>
            </div>
        `)

        // loading 
        $('.chat-container').append(`
            <div class="chat-message bottalk" id="loading">
                <span><b>...</b></span>
            </div>
        `)

        // clear the text input 
        $('#input_message').val('')

        // send the message
        submit_message(input_message)
        document.getElementById("words").scrollTop=document.getElementById("words").scrollHeight
        e.preventDefault();
      }
    };

$('#target').on('submit', function(e){
        e.preventDefault();
        const input_message = $('#input_message').val()
        // return if the user does not enter any text
        if (!input_message) {
          return
        }

        $('.chat-container').append(`
            <div class="chat-message humantalk" ><span>
                ${input_message.replace("<","&lt;").replace(">","&gt;")}
                </span>
            </div>
        `)

        // loading 
        $('.chat-container').append(`
            <div class="chat-message bottalk" id="loading">
                <span><b>...</b></span>
            </div>
        `)

        // clear the text input 
        $('#input_message').val('')

        // send the message
        submit_message(input_message)
        document.getElementById("words").scrollTop=document.getElementById("words").scrollHeight
    });




 $('#hint').click(function(e){
      e.preventDefault();
      $('.chat-container').append(`
        <div class="chat-message bottalk"><span>
        I can tell you some infomation about movies:<br/>
        &spades;. Enter the name of the movie you want to know and add '&lt; &gt;'.<br/>
          &nbsp;&nbsp;&nbsp;&nbsp;For example, you can enter 'I wanna know &lt;Thor&gt;.<br/>
        &diams;. Enter 'top movie list', like 'I wanna know the top movie list'. I will show you the top 10.<br/>
        &hearts;. Enter movie type, like 'I wanna know action movie'. I will show you some this type movies.<br/>
        &clubs;. Enter 'I would like to evaluate the movie <XXXXX>'  or 'I want to comment the movie <XXXXXX>'.<br/>
        &nbsp;&nbsp;&nbsp;&nbsp;For example: 'I would like to evaluate the movie <Up>'. And I can justify your emotion.<br/>
        &spades;.Enter 'predict the rate of a movie' or 'I want to get a prediction of a movie\'s rate'. <br/>
        &nbsp;&nbsp;&nbsp;&nbsp;And input parameters I needed,I can predict the score for you.
        </span>
        </div>` )
      document.getElementById("words").scrollTop=document.getElementById("words").scrollHeight
      });






const animationType = 'headShake'
const bob = document.querySelectorAll('.blob')[0];
const body = document.getElementsByTagName('body')[0];

bob.addEventListener('mouseenter', () => {
  bob.classList.add(animationType);
});

bob.addEventListener('mouseleave', () => {
  bob.classList.remove(animationType);
});

body.addEventListener('mousemove', (e) => {
  if (e.clientY < bob.offsetHeight) {
    bob.classList.add('look-up');
  } else {
    bob.classList.remove('look-up');
  }
  
  if (e.clientY > (bob.offsetHeight + 150)) {
    bob.classList.add('look-down');
  } else {
    bob.classList.remove('look-down');
  }


  if (e.clientX < (bob.offsetLeft)) {
    bob.classList.add('look-left');
  } else {
    bob.classList.remove('look-left');
  }  

  if (e.clientX > (bob.offsetLeft + 200)) {
    bob.classList.add('look-right');
  } else {
    bob.classList.remove('look-right');
  }   
});