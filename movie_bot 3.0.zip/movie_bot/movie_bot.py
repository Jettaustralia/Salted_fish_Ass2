import os
import dialogflow
import pymysql
import requests
from flask import Flask,session
from flask import render_template,redirect,abort,make_response,url_for
from flask import request, jsonify
from flask_restplus import Resource, Api,fields,reqparse
from functools import wraps
from auth import AuthenticationToken
from predict_score.rate_pred import input_string_rate
# from predict_emotion.emotion_pre import input_sentence_emo

user_list = []

db = pymysql.connect(host='database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com', user='admin', password='19950423',port=3306, db='Movie')
cursor = db.cursor()

def after_request(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'PUT,GET,POST,DELETE'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
    return response
#def connect_to_db():
    
app = Flask(__name__)
app.after_request(after_request)
app.secret_key = 'SECRET'
expires_in = 600
auth = AuthenticationToken(app.secret_key, expires_in)
# api = Api(app)
api = Api(app, authorizations={
    'API-KEY': {
        'type': 'apiKey',
        'in': 'header',
        'name': 'AUTH_TOKEN'
    }
},
          security='API-KEY',
          default="Movie_bot",  # Default namespace
          title="Movie Dataset",  # Documentation Title
          description="This is an introduction of service")  # Documentation Description

credential_model = api.model('credential', {
    'username': fields.String,
    'password': fields.String
})

credential_parser = reqparse.RequestParser()
credential_parser.add_argument('username', type=str)
credential_parser.add_argument('password', type=str or int)

def detect_intent_texts(session_id, texts, language_code='en-US',project_id='movie-qijbmr'):
    path = os.path.join((os.path.dirname(os.path.abspath('api_test.py'))),
                        'Movie-a8de2ddc64b9.json')
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = path
    session_client = dialogflow.SessionsClient()

    session = session_client.session_path(project_id, session_id)
    text_input = dialogflow.types.TextInput(
        text=texts, language_code=language_code)
    query_input = dialogflow.types.QueryInput(text=text_input)
    response = session_client.detect_intent(
        session=session, query_input=query_input)       
    return response
    
def get_movie_info(movie_name):    
    response = ''
    sql_query = "SELECT Description FROM movie where Title = %s"
    cursor.execute(sql_query, movie_name)
    result = cursor.fetchall()
    db.commit()
    # print('result', result)
    if not result:
        response += f"Sorry,there is no movie called {movie_name},please check it"
    else:
        result = result[0][0]
        response += str(result)
    return response

def movie_recommed(movie_type):
    response = ''
    print(movie_type)
    movie_type_1 = "%" + movie_type + "%"
    response = ''
    sql_query = "SELECT Title FROM movie where Genre like %s order by Rating DESC "
    cursor.execute(sql_query, movie_type_1)
    result = cursor.fetchall()
    response += f"Here are top rating {movie_type} movie for you:\n"
    if len(result) > 5:
        for i in range(5):
            response += (result[i][0])
            response += "\n"
    else:
        for i in range(len(result)):
            response += (result[i][0])
            response += "\n"
    print(response)
    return response

def recommend_top_movie():
    response = ''
    response = 'Here are top10 rating movies for you:\n'
    sql_query = "SELECT Title FROM movie order by Metascore DESC "
    cursor.execute(sql_query)
    result = cursor.fetchall()
    for i in range(10):
        response += (result[i][0])
        response += "\n"
    print(response)
    return response

def movie_recommed(movie_type):
    response = ''
    movie_type_1 = "%" + movie_type + "%"
    db = pymysql.connect(host='database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com', user='admin', password='19950423',
                         port=3306, db='Movie')
    cursor = db.cursor()
    response = ''
    sql_query = "SELECT Title FROM movie where Genre like %s order by Rating DESC "
    cursor.execute(sql_query, movie_type_1)
    result = cursor.fetchall()
    response += f"Here are top rating {movie_type} movie for you:\n"
    if len(result) > 5:
        for i in range(5):
            response += (result[i][0])
            response += "\n"
    else:
        for i in range(len(result)):
            response += (result[i][0])
            response += "\n"
    print(response)
    return response

def auth_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        # token = request.headers.get('AUTH_TOKEN')
        token = session.get("token")
        print("token:",token)
        if not token: 
            return render_template('error.html')           
            # abort(401, 'Authentication token is missing')
            # return redirect('/main')
        try:
            user = auth.validate_token(token)
        except Exception as e:
            return render_template('error.html')    
            # abort(401, e)
        return f(*args, **kwargs)

    return decorated

@app.route('/main')
def search():
    session.clear()
    print(session)
    return render_template('login.html')

class login(Resource):
    # @app.route("/login", methods=['POST'])
    @api.response(200, 'Successful')
    @api.doc(description="Generates a authentication token")
    @api.expect(credential_parser, validate=True)
    def post(self):
        print('post')
        args = credential_parser.parse_args()
        username = args.get('username')
        password = args.get('password')
        auth_token = auth.generate_token(username)        
        client_info = {}
        for i in user_list:
            if username in i['username']:
                i['session'] += 1
                session['token'] = auth_token
                session["username"] = username
                response_text = {"token": auth_token}
                return jsonify(response_text)
        # print('user:',username)
        # print('pass:',password)
        client_info['username'] = username
        client_info['session'] = 1        
        session['token'] = auth_token
        session["username"] = username
        # user_list.append(session)
        user_list.append(client_info)
        response_text = {"token": auth_token}
        print(response_text)
        print(session)
        return jsonify(response_text)

api.add_resource(login,'/login')

@app.route('/view')
@api.doc(description="View the API usage of users")
@auth_required 
def view():
    username = session.get("username")
    page_visits = 1
    for user_session in user_list:
        if username == user_session.get("username"):
            page_visits = user_session.get("session")
    # info = user_list
    # print(info)
    return render_template('view.html',data=page_visits)


# class view_user(Resource):
#     # @auth_required    
#     # @api.route('/view')
#     def get(self):
#         info = user_list
#         print(info)
#         # json_data = json.dumps(info)
#         # return json_data,200
#         return render_template('view.html')
#         # return jsonify(info)

# api.add_resource(view_user,'/view')

# @app.route('/log_in',methods=['GET'])
# @api.response(200, 'Successful')
# @api.doc(description="Chat with bot")
# @auth_required  
# def log_in():
#     # print(request.headers)
#     return '/chat'

@app.route('/chat',methods=['GET'])
@api.response(200, 'Successful')
@api.doc(description="Chat with bot")
@auth_required  
def chat():
    return render_template('chat.html')


# @app.route('/movie_bot', methods=['POST'])
class movie_bot(Resource):     
    def post(self,input):      
        message = request.form['message']
        response = detect_intent_texts(2, message)
        intent = response.query_result.intent.display_name
        print(intent)
        data = response.query_result.parameters
        if intent == 'predict of a movie\'s rate - custom':
            input_data = response.query_result. query_text
            print(str(input_data))
            response = input_string_rate(str(input_data))
        elif intent == 'predict_comment_emotion':
            response = response.query_result.fulfillment_text
        elif intent == 'predict_comment_emotion - custom':
            input_data = (data.values()[0])
            print(input_data)
            response = input_sentence_emo(str(input_data))
        elif "Movie_name" in data :
            movie_name = data["Movie_name"].replace("<","").replace(">","")
            response = get_movie_info(movie_name)
        elif "movie_type" in data :
            movie_type = data["movie_type"]
            response = movie_recommed(movie_type)
        elif "recommend_part" in data:
            response = recommend_top_movie()
        elif intent == 'predict of a movie\'s rate':
            response = response.query_result.fulfillment_text
        elif intent == 'Default Fallback Intent' :
            response =  "I am quite confused"
        else:
            response = response.query_result.fulfillment_text
        # fulfillment_text = response
        reply = {"message": response}
        return jsonify(reply)
    
api.add_resource(movie_bot,'/movie_bot/<string:input>')


if __name__ == "__main__":
    app.run(
        host = '127.0.0.1',
        port = 5000,  
        debug = True)
