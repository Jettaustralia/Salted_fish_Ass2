from flask import request,jsonify
from flask import Flask,session
from api_test import detect_intent_texts
from flask_restplus import Resource, Api,fields,abort
import requests
import pymysql
from flask_restplus import fields
from flask_restplus import inputs
from flask_restplus import reqparse
import jwt
import datetime
from functools import wraps
from auth import AuthenticationToken
import json
from predict_score.rate_pred import input_string_rate
from predict_emotion.emotion_pre import input_sentence_emo

user_list = []
#def after_request(response):
#   response.headers['Access-Control-Allow-Origin'] = '*'
#   response.headers['Access-Control-Allow-Methods'] = 'PUT,GET,POST,DELETE'
#   response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
#   return response
def get_movie_info(movie_name):
    db = pymysql.connect(host='database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com', user='admin', password='19950423',port=3306, db='Movie')
    cursor = db.cursor()
    response = ''
    sql_query = "SELECT Description FROM movie where Title = %s"
    cursor.execute(sql_query, movie_name)
    result = cursor.fetchall()
    db.commit()
    if not result:
        response += f"Sorry,there is no movie called {movie_name},please check it"
    else:
        result = result[0][0]
        response += str(result)
    return response
def movie_recommed(movie_type):
    response = ''
    movie_type_1 = "%" + movie_type + "%"
    db = pymysql.connect(host='database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com', user='admin', password='19950423',
                         port=3306, db='Movie')
    cursor = db.cursor()
    response = ''
    sql_query = "SELECT Title FROM movie where Genre like %s order by Rating DESC "
    cursor.execute(sql_query, movie_type_1)
    result = cursor.fetchall()
    response += f"Here are top rating {movie_type} movie for you:\n"
    if len(result) > 5:
        for i in range(5):
            response += (result[i][0])
            response += "\n"
    else:
        for i in range(len(result)):
            response += (result[i][0])
            response += "\n"
    print(response)
    return response
def recommend_top_movie():
    response = ''
    db = pymysql.connect(host='database-1.clr3d8nnckz4.us-east-2.rds.amazonaws.com', user='admin', password='19950423',
                         port=3306, db='Movie')
    cursor = db.cursor()
    response = 'Here are top10 rating movies for you:\n'
    sql_query = "SELECT Title FROM movie order by Metascore DESC "
    cursor.execute(sql_query)
    result = cursor.fetchall()
    for i in range(10):
        response += (result[i][0])
        response += "\n"
    print(response)
    return response

app = Flask(__name__)
app.secret_key = 'SECRET'
expires_in = 600
auth = AuthenticationToken(app.secret_key, expires_in)
api = Api(app, authorizations={
        'API-KEY': {
                'type': 'apiKey',
                'in': 'header',
                'name': 'AUTH_TOKEN'
        }
},
                    security='API-KEY',
                    default="Movie_bot",  # Default namespace
                    title="Movie Dataset",  # Documentation Title
                    description="This is an introduction of service")  # Documentation Description

def auth_required(f):
    @wraps(f)
#   @api.response(401, 'Wrong Authentication, access refused')
    def decorated(*args, **kwargs):

        token = request.headers.get('AUTH_TOKEN')
        if not token:
            abort(401, 'Authentication token is missing')

        try:
            user = auth.validate_token(token)
        except Exception :
            abort(401, 'Wrong Authentication, access refused')
        return f(*args, **kwargs)

    return decorated
    
credential_model = api.model('credential', {
    'username': fields.String,
    'password': fields.String
})

credential_parser = reqparse.RequestParser()
credential_parser.add_argument('username', type=str,required = True ,help = 'Please input your username')
credential_parser.add_argument('password', type=str or int,required = True ,help = 'Please input your password')        
        
@api.route('/login')
class Login(Resource):
    @api.response(200, 'Successful')
    @api.doc(description="Generates a authentication token")
    @api.expect(credential_parser, validate=True)
    def post(self):
        args = credential_parser.parse_args()

        username = args.get('username')
        password = args.get('password')
        auth_token = auth.generate_token(username)
        client_info = {}
        for i in user_list:
            if username in i['username']:
                i['session'] += 1
                return {"token": auth_token}
        client_info['username'] = username
        client_info['session'] = 1
        user_list.append(client_info)
        session['token'] = auth_token
#       print(user_list)
        print(session)
        response_text = {"token": auth_token}

        return jsonify(response_text)




@api.route('/view')
class view_user(Resource):
    @auth_required
    @api.doc(description="View the API usage of users")
    def get(self):
        info = user_list
        reply = {'user_info' : info}
#       json_data = json.dumps(info)
        return jsonify(reply)

######################################################################################
    


# ????
@api.route('/main/<int:session_id>/<string:user_input>')
@api.param('session_id','use for the contex of the dialog')
@api.param('user_input','what the user input to the server')
class movie_bot(Resource):
    @api.response(200, 'Successful')
    @api.doc(description="Chat with bot")
#   @auth_required
    def post(self,session_id,user_input):
#       message = request.form['message']
#       print(message)
        response = detect_intent_texts(session_id, user_input)
#       print(response)
        intent = response.query_result.intent.display_name
#       print(intent)
        data = response.query_result.parameters
        if intent == 'predict of a movie\'s rate - custom':
            input_data = response.query_result. query_text
            print(str(input_data))
            response = input_string_rate(str(input_data))
#           return response,200
        elif intent == 'predict_comment_emotion':
            response = response.query_result.fulfillment_text
#           print(response.query_result.fulfillment_text)
#           return response,200
        elif intent == 'predict_comment_emotion - custom':
            input_data = (data.values()[0])
            print(input_data)
            response = input_sentence_emo(str(input_data))
#           return 'success',200
        elif "Movie_name" in data :
            movie_name = data["Movie_name"].replace("<","").replace(">","")
            response = get_movie_info(movie_name)
#           return response,200
        elif "movie_type" in data :
            movie_type = data["movie_type"]
            response = movie_recommed(movie_type)
#           return response, 200
        elif "recommend_part" in data:
            response = recommend_top_movie()
#           return response,200
        elif intent == 'predict of a movie\'s rate':
#           response = response.query_result.fulfillment_messages[0]
            response = response.query_result.fulfillment_text
#           print(response.query_result.fulfillment_text)
#           return response,200
        
        else:
            response =  "I am quite confused"
#       print(response)
        fulfillment_text = response
        reply = {"fulfillmentText": fulfillment_text,}
        return jsonify(reply)



if __name__ == "__main__":
    app.run(debug=True)
    
