from flask import request,jsonify
from flask import Flask, render_template
from api_test import detect_intent_texts
from flask_restplus import Resource, Api,fields,abort
import requests
import pymysql
from flask_restplus import fields
from flask_restplus import inputs
from flask_restplus import reqparse
import jwt
import datetime
from functools import wraps
class AuthenticationToken:
	def __init__(self, secret_key, expires_in):
		self.secret_key = secret_key
		self.expires_in = expires_in

	def generate_token(self, username):
		info = {
				'username': username,
				'exp': datetime.datetime.utcnow() + datetime.timedelta(seconds=self.expires_in)
		}
		return jwt.encode(info, self.secret_key, algorithm='HS256').decode(' utf-8 ')

	def validate_token(self, token):
		info = jwt.decode(token, self.secret_key, algorithms=['HS256'])
		return info['username']
